public class Pyramid {
    int baseLength, baseWidth, height;

    // Constructor
    Pyramid(int baseLength, int baseWidth, int height) {
        this.baseLength = baseLength;
        this.baseWidth = baseWidth;
        this.height = height;
    }

    // Method to calculate volume
    public double calcVol() {
        double baseArea = baseLength * baseWidth;
        return (1.0 / 3.0) * baseArea * height;
    }

    // Method to calculate surface area
    public double calSurfArea() {
        // Calculate the slant height
        double slantHeight = Math.sqrt(Math.pow(baseLength / 2.0, 2) + Math.pow(height, 2));
        
        // Calculate the perimeter of the base
        double perimeter = 2 * (baseLength + baseWidth);
        
        // Calculate the surface area
        double baseArea = baseLength * baseWidth;
        return baseArea + (0.5 * perimeter * slantHeight);
    }
}
import java.util.Scanner;

public class MyProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask the user what shape they want to calculate
        System.out.println("Choose a shape to calculate (Box/Sphere/Pyramid): ");
        String shape = scanner.nextLine().toLowerCase();

        // Process the shape based on user input
        if (shape.equals("box")) {
            // Input for box dimensions
            System.out.print("Enter length of the box: ");
            int length = scanner.nextInt();
            System.out.print("Enter width of the box: ");
            int width = scanner.nextInt();
            System.out.print("Enter height of the box: ");
            int height = scanner.nextInt();

            // Create a Box object and calculate volume and surface area
            Box box = new Box(length, width, height);
            System.out.println("Volume of the box: " + box.calcVol());
            System.out.println("Surface area of the box: " + box.calSurfArea());
        } else if (shape.equals("sphere")) {
            // Input for sphere radius
            System.out.print("Enter radius of the sphere: ");
            int radius = scanner.nextInt();

            // Create a Sphere object and calculate volume and surface area
            Sphere sphere = new Sphere(radius);
            System.out.println("Volume of the sphere: " + sphere.calcVol());
            System.out.println("Surface area of the sphere: " + sphere.calSurfArea());
        } else if (shape.equals("pyramid")) {
            // Input for pyramid base length, base width, and height
            System.out.print("Enter base length of the pyramid: ");
            int baseLength = scanner.nextInt();
            System.out.print("Enter base width of the pyramid: ");
            int baseWidth = scanner.nextInt();
            System.out.print("Enter height of the pyramid: ");
            int height = scanner.nextInt();

            // Create a Pyramid object and calculate volume and surface area
            Pyramid pyramid = new Pyramid(baseLength, baseWidth, height);
            System.out.println("Volume of the pyramid: " + pyramid.calcVol());
            System.out.println("Surface area of the pyramid: " + pyramid.calSurfArea());
        } else {
            System.out.println("Invalid shape choice.");
        }

        scanner.close();
    }
}
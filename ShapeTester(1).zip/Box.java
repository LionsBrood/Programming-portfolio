public class Box {
    int l, w, h;

    // Constructor
    Box(int l, int w, int h) {
        this.l = l;
        this.w = w;
        this.h = h;
    }

    // Method to calculate volume
    public int calcVol() {
        return l * w * h;
    }

    // Method to calculate surface area
    public int calSurfArea() {
        return 2 * (l * w + l * h + w * h);
    }
}